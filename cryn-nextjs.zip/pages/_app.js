import '../styles/globals.css'
import { useEffect } from 'react'
import Head from 'next/head'

export default function App({ Component, pageProps }) {
  useEffect(()=>{
    // disable next.js hydration flicker by forcing smooth scroll behaviour
    if (typeof window !== 'undefined') document.documentElement.style.scrollBehavior = 'smooth'
  },[])
  return (
    <>
      <Head>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
      </Head>
      <Component {...pageProps} />
    </>
  )
}