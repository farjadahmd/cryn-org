import { useEffect, useState } from 'react'
import Header from '../components/Header'
import Footer from '../components/Footer'
import { motion } from 'framer-motion'

import en from '../locales/en/common.json'
import ur from '../locales/ur/common.json'

export default function Home(){
  const [lang,setLang] = useState('en')
  const t = (k)=>{
    const dict = lang==='en'?en:ur
    return dict[k] || k
  }
  const switchLang = ()=> setLang(l=> l==='en' ? 'ur' : 'en')

  useEffect(()=>{
    // simple fade-up reveal
    document.querySelectorAll('.reveal').forEach((el, i)=>{
      setTimeout(()=> el.classList.add('show'), 120*i)
    })
  },[])

  return (
    <div>
      <Header t={t} switchLang={switchLang} />
      <main className="pt-24">
        {/* HERO with VIDEO BACKGROUND */}
        <section id="home" className="relative h-screen flex items-center">
          <video autoPlay muted loop playsInline className="absolute inset-0 w-full h-full object-cover opacity-60">
            <source src="https://cdn.coverr.co/videos/coverr-solar-panels-on-a-grid-1584?token=eyJhbGciOiJIUzI1NiJ9" type="video/mp4" />
          </video>
          <div className="absolute inset-0 bg-gradient-to-t from-white/80 via-white/30 to-transparent"></div>
          <div className="max-w-6xl mx-auto px-6 relative z-10 flex flex-col md:flex-row items-center gap-8">
            <div className="flex-1">
              <motion.h1 initial={{opacity:0,y:10}} animate={{opacity:1,y:0}} transition={{delay:0.15}} className="text-4xl md:text-5xl font-extrabold leading-tight"> {t('Empowering youth for climate resilience')}</motion.h1>
              <motion.p initial={{opacity:0,y:10}} animate={{opacity:1,y:0}} transition={{delay:0.25}} className="mt-4 text-gray-600 max-w-xl"> {t('CRYN trains & connects young leaders to design community-first solutions that build resilience to climate shocks.')}</motion.p>
              <div className="mt-6 flex gap-4">
                <a href="#getinvolved" className="btn-primary">{t('Join CRYN')}</a>
                <a href="#work" className="px-4 py-2 border rounded-full">{t('Our Work')}</a>
              </div>
            </div>
            <div className="flex-1">
              <img src="/logo.png" alt="logo" className="rounded-xl shadow-2xl" />
            </div>
          </div>
        </section>

        <section id="about" className="section">
          <div className="max-w-6xl mx-auto px-6">
            <h2 className="text-2xl font-semibold mb-2">{t('About CRYN')}</h2>
            <p className="text-gray-600 mb-4">{t('Climate Resilience Youth Network (CRYN) is a youth-led organisation focused on empowering communities to adapt and thrive in a changing climate.')}</p>

            <div className="grid md:grid-cols-3 gap-4">
              <div className="card reveal p-6 bg-white rounded-xl shadow-sm">
                <h3 className="font-semibold mb-2">{t('Our Vision')}</h3>
                <p className="text-gray-600">{t('A resilient future where youth lead climate solutions.')}</p>
              </div>
              <div className="card reveal p-6 bg-white rounded-xl shadow-sm">
                <h3 className="font-semibold mb-2">{t('Our Approach')}</h3>
                <p className="text-gray-600">{t('Community-first, data informed, and partnership driven.')}</p>
              </div>
              <div className="card reveal p-6 bg-white rounded-xl shadow-sm">
                <h3 className="font-semibold mb-2">{t('Impact')}</h3>
                <p className="text-gray-600">{t('We run trainings, restoration, and policy engagement with measurable outcomes.')}</p>
              </div>
            </div>
          </div>
        </section>

        <section id="work" className="section bg-gray-50">
          <div className="max-w-6xl mx-auto px-6">
            <h2 className="text-2xl font-semibold mb-2">{t('Our Work')}</h2>
            <p className="text-gray-600 mb-4">{t('From mangrove restoration to urban heat mapping—our projects combine field action with youth leadership.')}</p>
            <div className="grid md:grid-cols-3 gap-6">
              <div className="project card p-4 bg-white rounded-xl shadow-sm reveal">
                <img src="https://images.unsplash.com/photo-1501004318641-b39e6451bec6?q=80&w=1200&auto=format&fit=crop" className="rounded-md mb-3" alt="mangrove" />
                <h4 className="font-semibold">Mangrove Restoration</h4>
                <p className="text-gray-600">Community planting & monitoring.</p>
              </div>
              <div className="project card p-4 bg-white rounded-xl shadow-sm reveal">
                <img src="https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?q=80&w=1200&auto=format&fit=crop" className="rounded-md mb-3" alt="heat" />
                <h4 className="font-semibold">Urban Heat Mapping</h4>
                <p className="text-gray-600">Mapping heat islands & greening pilots.</p>
              </div>
              <div className="project card p-4 bg-white rounded-xl shadow-sm reveal">
                <img src="https://images.unsplash.com/photo-1526481280698-32b6b83c32d5?q=80&w=1200&auto=format&fit=crop" className="rounded-md mb-3" alt="schools" />
                <h4 className="font-semibold">School Curriculum</h4>
                <p className="text-gray-600">Hands-on climate modules.</p>
              </div>
            </div>
          </div>
        </section>

        <section id="resources" className="section">
          <div className="max-w-6xl mx-auto px-6">
            <h2 className="text-2xl font-semibold mb-2">{t('Resources')}</h2>
            <p className="text-gray-600 mb-4">{t('Guides, toolkits and datasets to support youth climate action.')}</p>
            <ul className="space-y-2">
              <li><a className="text-accent font-semibold" href="#">{t('Community Resilience Toolkit (PDF)')}</a></li>
              <li><a className="text-accent font-semibold" href="#">{t('Heat Mapping Guide')}</a></li>
              <li><a className="text-accent font-semibold" href="#">{t('Monitoring & Evaluation Template')}</a></li>
            </ul>
          </div>
        </section>

        <section id="getinvolved" className="section bg-gray-50">
          <div className="max-w-6xl mx-auto px-6">
            <h2 className="text-2xl font-semibold mb-2">{t('Get Involved')}</h2>
            <p className="text-gray-600 mb-4">{t('Volunteers, partners and donors welcome. Fill the form and we’ll get back to you.')}</p>
            <form name="join" method="POST" data-netlify="true" className="grid gap-3 max-w-md">
              <input type="hidden" name="form-name" value="join" />
              <label className="flex flex-col"><span>{t('Name')}</span><input name="name" className="border p-2 rounded-md" required/></label>
              <label className="flex flex-col"><span>{t('Email')}</span><input name="email" type="email" className="border p-2 rounded-md" required/></label>
              <label className="flex flex-col"><span>{t('Message')}</span><textarea name="message" rows="4" className="border p-2 rounded-md"></textarea></label>
              <button className="btn-primary" type="submit">{t('Apply')}</button>
            </form>
          </div>
        </section>

        <section id="contact" className="section">
          <div className="max-w-6xl mx-auto px-6">
            <h2 className="text-2xl font-semibold mb-2">{t('Contact')}</h2>
            <p className="text-gray-600 mb-4">{t('Email:')} <a href="mailto:climateryn@gmail.com">climateryn@gmail.com</a> | {t('Phone:')} <a href="tel:+923303344338">+92 330 3344338</a></p>
            <div className="grid md:grid-cols-2 gap-4">
              <div className="card p-4 rounded-xl shadow-sm">
                <h4 className="font-semibold">{t('Head Office')}</h4>
                <p className="text-gray-600">Karachi / Lahore (remote)</p>
              </div>
              <div className="card p-4 rounded-xl shadow-sm">
                <h4 className="font-semibold">{t('Follow')}</h4>
                <p className="text-gray-600"><a href="https://www.instagram.com/climateresilienceyouthnetwork/?utm_source=ig_web_button_share_sheet" target="_blank" rel="noreferrer">Instagram</a></p>
              </div>
            </div>
          </div>
        </section>

      </main>
      <Footer t={(k)=>k} />
      <script dangerouslySetInnerHTML={{__html:`
        // IntersectionObserver for reveal
        (function(){
          const io = new IntersectionObserver((entries)=>{
            entries.forEach(e=>{ if(e.isIntersecting) e.target.classList.add('show'); })
          },{threshold:0.12});
          document.querySelectorAll('.reveal').forEach(el=>io.observe(el));
        })();
      `}} />
    </div>
  )
}
