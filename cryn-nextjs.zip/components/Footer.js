export default function Footer({t}){
  return (
    <footer className="bg-white border-t mt-12">
      <div className="max-w-6xl mx-auto p-6 flex flex-col md:flex-row justify-between gap-4 items-center">
        <div>© {new Date().getFullYear()} CRYN</div>
        <div className="text-sm">Email: <a href="mailto:climateryn@gmail.com">climateryn@gmail.com</a> | Phone: <a href="tel:+923303344338">+92 330 3344338</a></div>
      </div>
    </footer>
  )
}