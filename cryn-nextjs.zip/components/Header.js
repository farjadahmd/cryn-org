import Image from 'next/image'
import { useState } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/router'

export default function Header({ t, switchLang }){
  const [open,setOpen] = useState(false)
  const router = useRouter()
  const nav = [
    {href:'#home', label:t('Home')},
    {href:'#about', label:t('About')},
    {href:'#work', label:t('Our Work')},
    {href:'#resources', label:t('Resources')},
    {href:'#getinvolved', label:t('Get Involved')},
    {href:'#contact', label:t('Contact')},
  ]
  return (
    <header className="fixed w-full z-50 header-glass shadow-sm">
      <div className="max-w-6xl mx-auto flex items-center justify-between p-4">
        <a href="#home" className="flex items-center gap-3">
          <Image src="/logo.png" alt="CRYN" width={48} height={48} className="rounded-md" />
          <span className="font-semibold">CRYN</span>
        </a>
        <nav className="hidden md:flex gap-6 items-center">
          {nav.map(i=> <a key={i.href} href={i.href} className="hover:text-accent">{i.label}</a>)}
          <a href="https://www.instagram.com/climateresilienceyouthnetwork/?utm_source=ig_web_button_share_sheet" target="_blank" rel="noreferrer" className="ml-4">Instagram</a>
          <button onClick={switchLang} className="ml-4 px-3 py-1 rounded-md border">{t('Language')}</button>
        </nav>
        <div className="md:hidden flex items-center gap-3">
          <a href="https://www.instagram.com/climateresilienceyouthnetwork/?utm_source=ig_web_button_share_sheet" target="_blank" rel="noreferrer">IG</a>
          <button onClick={()=>setOpen(!open)} className="px-3 py-1 border rounded-md">{open? 'Close':'Menu'}</button>
        </div>
      </div>
      {open && <div className="md:hidden bg-white p-4 border-t">
        {['Home','About','Our Work','Resources','Get Involved','Contact'].map(x=> <div key={x} className="py-2"><a href={'#'+x.toLowerCase().replace(/ /g,'')}>{t(x)}</a></div>)}
        <div className="py-2"><button onClick={switchLang} className="px-3 py-1 border rounded-md">{t('Language')}</button></div>
      </div>}
    </header>
  )
}
